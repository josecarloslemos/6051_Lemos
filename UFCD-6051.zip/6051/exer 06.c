


 #include <stdio.h>

 int main()
 {
    int contador = 0;

    for (contador = 0; contador < 10; contador++)
    {
        printf("contador: %d\n", contador);
    }

    contador = 0;



    while(contador < 10);
    

    printf("contador: %d\n",contador);


    contador++;
