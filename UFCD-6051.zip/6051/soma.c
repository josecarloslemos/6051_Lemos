#include <stdio.h>

int main()
{ 
      int x  = 0;
      int y  = 0;

      x = 10;
      y = 5;

      int sum = x + y;

      printf("sun: %d" , sum);
}
  