#include <stdio.h>

int main()
{
    int x = 0;
    int Y = 0;

    scanf("%d",&x);
    scanf("%d",&Y);

 int sum = x + Y;

 printf("sun: %d", sum);

 return 0;



}