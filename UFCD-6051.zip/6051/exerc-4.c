#include <stdio.h>

int main()

 switch (operador)
 {
    case '+':
        resultado = x + y;
        break;

    case '-':
        resultado = x - y;
        break;
    case '*':
        resultado = x * y;
        break;
     case '/':
        resultado = x / y;
                    